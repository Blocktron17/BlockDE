#!/usr/bin/env python3
"""
Simple multithreaded HTTP/HTTPS proxy server (Python 3).
- Basic HTTP forwarding and CONNECT tunneling for HTTPS.
- No caching, no authentication, no TLS interception (no MITM).
- Educational / local testing only. NOT production-secure.
"""

import socket
import threading
import select
import sys
import logging
import os
from urllib.parse import urlsplit

LISTEN_ADDR = '0.0.0.0'
LISTEN_PORT = 8888
BUFFER_SIZE = 4096
TIMEOUT = 10.0
MAX_HEADER_BYTES = 65536

logging.basicConfig(level=logging.INFO, format='[%(asctime)s] %(message)s')


def open_file(path):
    """Return file content or None if unreadable."""
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return f.read()
    except Exception:
        return None


# Load optional HTML templates; fall back to simple strings
blocked_site = open_file("Proxy/block.html") or "<html><body><h1>Blocked</h1></body></html>"
error_400 = "<html><body><h1>400 Bad Request</h1></body></html>"
error_502 = "<html><body><h1>502 Bad Gateway</h1></body></html>"
error_504 = "<html><body><h1>504 Gateway Timeout</h1></body></html>"


def send_response(sock, status_code, reason, body, close=True):
    """Send a simple HTTP response (best-effort)."""
    try:
        if isinstance(body, str):
            body_bytes = body.encode('utf-8')
        else:
            body_bytes = body
        headers = (
            f"HTTP/1.1 {status_code} {reason}\r\n"
            "Content-Type: text/html; charset=utf-8\r\n"
            f"Content-Length: {len(body_bytes)}\r\n"
            + ("Connection: close\r\n" if close else "Connection: keep-alive\r\n")
            + "\r\n"
        ).encode('utf-8')
        sock.sendall(headers + body_bytes)
    except Exception:
        logging.debug("Failed to send response to client (best-effort).")


def parse_host_port(host_port, default_port):
    """
    Parse host:port or [ipv6]:port. Returns (host, port).
    """
    # bracketed IPv6: [::1]:443
    if host_port.startswith('['):
        # find closing bracket
        end = host_port.find(']')
        if end == -1:
            return host_port, default_port
        host = host_port[1:end]
        rest = host_port[end + 1:]
        if rest.startswith(':'):
            try:
                return host, int(rest[1:])
            except Exception:
                return host, default_port
        else:
            return host, default_port
    # otherwise rsplit on last colon (to handle IPv6 without brackets poorly, but okay for most)
    if ':' in host_port and host_port.count(':') == 1:
        h, p = host_port.rsplit(':', 1)
        try:
            return h, int(p)
        except Exception:
            return host_port, default_port
    return host_port, default_port


def handle_client(client_sock, client_addr):
    client_sock.settimeout(TIMEOUT)
    remote = None
    bpath = None  # for logging when we replaced a path
    try:
        # Read request headers (simple, not fully RFC-compliant)
        request = b''
        while b'\r\n\r\n' not in request:
            chunk = client_sock.recv(BUFFER_SIZE)
            if not chunk:
                return
            request += chunk
            if len(request) > MAX_HEADER_BYTES:
                logging.warning("Headers too large; dropping connection")
                return

        header_end = request.find(b'\r\n\r\n') + 4
        head = request[:header_end].decode('utf-8', errors='replace')
        # parse request line
        try:
            first_line = head.splitlines()[0].strip()
            method, path, proto = first_line.split()

        except Exception:
            logging.warning("Malformed request from %s", client_addr)
            send_response(client_sock, 400, "Bad Request", error_400)
            return

        logging.info(f"{client_addr} -> {method} {path}")
        if "youtube.com/shorts/" in path or path.startswith("/shorts/"):
            send_response(client_sock, 403, body=b"<h1>Blocked: YouTube Shorts</h1>")
            return
        if method.upper() == 'CONNECT':
            # CONNECT tunneling (HTTPS)
            host_port = path
            host, port = parse_host_port(host_port, 443)
            try:
                remote = socket.create_connection((host, port), timeout=TIMEOUT)
            except socket.gaierror:
                logging.info(f"Site blocked (DNS) for CONNECT: {host_port}")
                send_response(client_sock, 403, "Forbidden", blocked_site)
                return
            except socket.timeout:
                logging.info(f"Timeout connecting to {host_port}")
                send_response(client_sock, 504, "Gateway Timeout", error_504)
                return
            except Exception as e:
                logging.exception("Error connecting to remote for CONNECT: %s", e)
                send_response(client_sock, 502, "Bad Gateway", error_502)
                return

            # Tunnel established
            try:
                client_sock.sendall(b"HTTP/1.1 200 Connection established\r\n\r\n")
            except Exception:
                logging.debug("Failed to reply 200 to client for CONNECT")
                remote.close()
                return
            tunnel_sockets(client_sock, remote)
            return

        else:
            # HTTP (origin-form) requests
            # find Host header
            headers = head.split('\r\n')[1:]
            host_hdr = None
            for h in headers:
                if h.lower().startswith('host:'):
                    host_hdr = h.split(':', 1)[1].strip()
                    break
            if not host_hdr:
                logging.warning("No Host header from %s; dropping", client_addr)
                send_response(client_sock, 400, "Bad Request", error_400)
                return

            # convert absolute URL to origin-form path if needed
            if path.startswith('http://') or path.startswith('https://'):
                try:
                    u = urlsplit(path)
                    # include path + query
                    path = u.path or '/'
                    if u.query:
                        path = path + '?' + u.query
                except Exception:
                    path = '/'

            # determine remote host/port
            remote_host, remote_port = (host_hdr, 80) if ':' not in host_hdr else (host_hdr.split(':', 1)[0], int(host_hdr.split(':', 1)[1]))

            # Build sanitized request: rebuild request-line to use origin-form path
            request_lines = head.split('\r\n')
            # Reconstructed first line: method <path> <proto>
            req_line = f"{method} {path} {proto}"
            # Sanitize other headers
            new_lines = [req_line]
            found_connection = False
            for line in request_lines[1:]:
                if not line:
                    continue
                low = line.lower()
                if low.startswith('proxy-connection:'):
                    continue
                if low.startswith('connection:'):
                    # force close
                    new_lines.append('Connection: close')
                    found_connection = True
                    continue
                # keep other headers unchanged (but avoid sending hop-by-hop headers)
                if low.startswith('proxy-authenticate:') or low.startswith('proxy-authorization:'):
                    continue
                new_lines.append(line)
            if not found_connection:
                new_lines.append('Connection: close')
            new_head = '\r\n'.join(new_lines) + '\r\n\r\n'

            # connect to upstream
            try:
                remote = socket.create_connection((remote_host, remote_port), timeout=TIMEOUT)
            except socket.gaierror:
                logging.info(f"Site Blocked at: {bpath or remote_host}")
                send_response(client_sock, 403, "Forbidden", blocked_site)
                return
            except socket.timeout:
                logging.info(f"Timeout connecting to upstream {remote_host}:{remote_port}")
                send_response(client_sock, 504, "Gateway Timeout", error_504)
                return
            except ConnectionRefusedError:
                logging.info("Connection refused by upstream %s:%s", remote_host, remote_port)
                send_response(client_sock, 502, "Bad Gateway", error_502)
                return
            except Exception as e:
                logging.exception("Error connecting to upstream %s:%s: %s", remote_host, remote_port, e)
                send_response(client_sock, 502, "Bad Gateway", error_502)
                return

            # forward request (headers + any body bytes already read beyond header_end)
            try:
                remote.sendall(new_head.encode('utf-8') + request[header_end:])
            except Exception:
                logging.exception("Failed to send request to upstream")
                send_response(client_sock, 502, "Bad Gateway", error_502)
                return

            # relay upstream response
            try:
                while True:
                    data = remote.recv(BUFFER_SIZE)
                    if not data:
                        break
                    client_sock.sendall(data)
            except socket.timeout:
                logging.info("Timeout while reading from upstream; closing")
            except Exception:
                logging.exception("Error relaying response")
            finally:
                pass

    except socket.timeout:
        logging.info(f"Timeout from {client_addr}")
        send_response(client_sock, 504, "Gateway Timeout", error_504)
    except Exception as e:
        logging.exception("Unhandled error handling client %s: %s", client_addr, e)
        try:
            send_response(client_sock, 502, "Bad Gateway", error_502)
        except Exception:
            pass
    finally:
        try:
            if remote:
                remote.close()
        except Exception:
            pass
        try:
            client_sock.close()
        except Exception:
            pass


def tunnel_sockets(a, b):
    """Bidirectional tunnel between sockets a and b until closed."""
    # set non-blocking for select-loop
    a.setblocking(False)
    b.setblocking(False)
    sockets = [a, b]
    try:
        while True:
            r, w, x = select.select(sockets, [], sockets, TIMEOUT)
            if x:
                break
            if not r:
                # timeout with no activity - break
                break
            for s in r:
                other = b if s is a else a
                try:
                    data = s.recv(BUFFER_SIZE)
                    if not data:
                        return
                    other.sendall(data)
                except (BlockingIOError, InterruptedError):
                    continue
                except Exception:
                    logging.exception("Tunnel relay exception")
                    return
    except Exception:
        logging.exception("Tunnel error")
    finally:
        for sock in (a, b):
            try:
                sock.shutdown(socket.SHUT_RDWR)
            except Exception:
                pass
            try:
                sock.close()
            except Exception:
                pass


def main():
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind((LISTEN_ADDR, LISTEN_PORT))
    srv.listen(100)
    logging.info(f"Proxy listening on {LISTEN_ADDR}:{LISTEN_PORT}")

    try:
        while True:
            client_sock, client_addr = srv.accept()
            t = threading.Thread(target=handle_client, args=(client_sock, client_addr), daemon=True)
            t.start()
    except KeyboardInterrupt:
        logging.info("Shutting down proxy")
    finally:
        srv.close()


if __name__ == '__main__':
    main()
