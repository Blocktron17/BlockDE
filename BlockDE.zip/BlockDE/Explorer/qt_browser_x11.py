#!/usr/bin/env python3
import os, sys
from PySide6.QtWidgets import QApplication
from PySide6.QtWebEngineWidgets import QWebEngineView
from PySide6.QtCore import QUrl, QEventLoop, QTimer

# Chromium flags: headless-friendly + GPU path
os.environ["QTWEBENGINE_CHROMIUM_FLAGS"] = (
    "--no-sandbox --disable-dev-shm-usage "
    "--use-gl=angle --enable-webgl --ignore-gpu-blocklist"
)

URL = "https://www.google.com"
OUT = "/dev/shm/google_fb.png"

app = QApplication(sys.argv)
view = QWebEngineView()
view.resize(1280, 800)
view.load(QUrl(URL))
view.show()  # must show to allow painting, even in framebuffer

# wait for load
loop = QEventLoop()
view.loadFinished.connect(lambda ok: loop.quit())

timer = QTimer()
timer.setSingleShot(True)
timer.timeout.connect(loop.quit)
timer.start(20000)
loop.exec()

# allow painting
paint_loop = QEventLoop()
QTimer.singleShot(500, paint_loop.quit)
paint_loop.exec()

pix = view.grab()
if pix.isNull():
    print("Grab failed → check framebuffer / flags")
else:
    pix.save(OUT, "PNG")
    print("Saved screenshot:", OUT)
app.quit()
