//Include Necessary Header files
#include <stdlib.h>

int integer_math(int int1, char operand, int int2){
    int result = 0;
    if (operand == '+') {
        result = int1 + int2;
    } else if (operand == '-') {
        result = int1 - int2;
    } else if (operand == '*') {
        result = int1*int2;
    } else if (operand == '/') {
        result = int1/int2;
    } else if (operand == '%') {
        result = int1 + int2;
    }
    return  result;
}

double Float_math(float int1, float operand, float int2) {
    double result = 0;
    if (operand == '+') {
        result = int1 + int2;
    } else if (operand == '-') {
        result = int1 - int2;
    } else if (operand == '*') {
        result = int1*int2;
    } else if (operand == '/') {
        result = int1/int2;
    } else if (operand == '%') {
        result = int1 + int2;
    }
    return  result;
}

char run_bash(char command){
    char result = system(&command);
    return result;
}