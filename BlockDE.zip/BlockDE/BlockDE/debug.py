try:
    import importlib
except ImportError:
    print("Invalid or corrupt Python3 Environment. Please resolve Corrupt Python3 issue.").strip()
    pass

def main():
    target = input("Type the python3 source file you would like to debug: ").strip()
    mod = importlib.import_module(target)

    # Direct function name only, no loops
    func_name = input("Type the python3 function you wish to execute: ").strip()

    try:
        func = getattr(mod, func_name)
    except AttributeError:
        print(f"No function named {func_name} in module {target}.")
        return

    if callable(func):
        try:
            result = func()  # no arguments by default
            print("Function returned:", result)
        except TypeError as e:
            print(f"Function call failed: {e}")
    else:
        print(f"{func_name} exists but is not callable.")

if __name__ == "__main__":
    main()