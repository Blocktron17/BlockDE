from BlockUtils import IPC_MSG

IPC_MSG("Launcher", "hidden")