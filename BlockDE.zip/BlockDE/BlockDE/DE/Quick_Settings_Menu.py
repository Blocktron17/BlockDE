#!/bin/python3.13
import pygame
import time
import os
import subprocess
import BlockUtils as q

current_win_prop = [380, 300]
current_info = [0, 1, 0, 1]

displays=q.get_monitor_details()
print(displays)
primary_monitor=q.find_primary_display(displays)

print("PID:", os.getpid())
pygame.font.init()
os.environ['SDL_VIDEO_WINDOW_POS'] = f"{displays[primary_monitor][0]+displays[primary_monitor][2]-380},{displays[primary_monitor][1]+displays[primary_monitor][3]-30-current_win_prop[1]-5}"  # X=100, Y=200
window = pygame.display.set_mode((current_win_prop[0], current_win_prop[1]), (pygame.NOFRAME))
font=pygame.font.Font(None, 16)

running=True


def Mesh_func():
    try:
        a, b = q.Get_Brightness()
        c = q.Get_Volume()
        d = int(q.open_file(path="/dev/shm/BlockDE/Data.txt"))
        if d > 0:
            n = True
        elif d == 0:
            n = False
        current_info.clear()
        current_info.append(a)
        current_info.append(b)
        current_info.append(c)
        current_info.append(n)

    except Exception as e:
        print(f"An initialization error has occurred. Restarting Service.({e})")
        pass

conf = 'Dark '.split()

def main():
    pid = os.getpid()
    time.sleep(0.2)
    # Get window id from PID
    win_id = subprocess.check_output(["xdotool", "search", "--pid", str(pid)])
    win_id = win_id.decode().split()[0]
    q.Minimize_APP(win_id, 'Start_Menu')
    # Force always-on-top
    q.subprocess.call(["wmctrl", "-i", "-r", win_id, "-b", "add,skip_taskbar"])
    q.subprocess.call(["wmctrl", "-i", "-r", win_id, "-b", "add,above"])
    q.subprocess.call(["wmctrl", "-i", "-r", win_id, "-b", "add,dock"])
    running = True
    target = float(f'{q.datetime.datetime.now()}'.split()[1].split(':')[2])+2
    q.UI.Update_UI=True
    Mesh_func()
    q.UI.Update_UI=True
    l=None
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        keys = pygame.key.get_pressed()
        if keys[pygame.K_ESCAPE] or not l == None:
            pygame.event.clear()
            q.Minimize_APP(win_id, 'Start_Menu')

        mx, my = pygame.mouse.get_pos()
        if mx > 0 and mx <= displays[primary_monitor][2] and my > 0:
            q.pygame.display.flip()
            q.run_bash(f"wmctrl -i -a {win_id}")

        if conf[0]=="Dark":
            window.fill((20,20,20))
        else:
            window.fill((255,255,255))
        #Session Options
        l=q.Render_UI(0,0,30,30,(255,165,0), "🌘",16,click_func=q.run_bash,flags="systemctl suspend", flags1=False, window=window)
        l=q.Render_UI(30,0,30,30,(255,165,0), "🔁",16,click_func=q.run_bash,flags="systemctl reboot", flags1=False, window=window)
        l=q.Render_UI(60,0,30,30,(255,165,0), "⚡",16,click_func=q.run_bash,flags="systemctl poweroff", flags1=False, window=window)
        l=q.Render_UI(90,0,30,30,(255,165,0), "🔐",16,click_func=q.run_bash,flags="openbox --exit", flags1=False, window=window)
        l=q.Render_UI(current_win_prop[0]-30,0,30,30,(255,165,0), "X",16,click_func=q.run_bash,flags="echo leaving menu", flags1=False, window=window)
        #Percent Meters
        q.Render_UI(25,226,30,16,(20,20,20),f"Sound({current_info[2]})",tRGB=(0,165,165), window=window)
        q.Percent_Bar(int(current_info[2]), 100, 15, 242, 350, 10, changeable=True, with_func=q.Set_Volume, window=window)
        q.Render_UI(41,262,30,16,(20,20,20),f"Brightness({(current_info[0]/current_info[1]*100).__round__()})",tRGB=(0,165,165), window=window)
        q.Percent_Bar(current_info[0], current_info[1], 15, 278, 350, 10, changeable=True, with_func=q.Set_Brightness, window=window)
        """
        This cluster of functions below, govern the behavior of these systems:
        1. Wifi: This button will toggle the wifi opttion off/on, while providing an option to display a network config menu.
        2. Airplane-Mode: Disables wifi & Bluetooth, along with any supported networking components.
        3. Power-Saver: This button allows for the user to enable power efficeincy mode.
        4. Accessibility: This option will trigger the activation of a program designed to configure accessibility options for the current user.
        """
        q.Render_Button(10, 50, 120, 50, on_func="nmcli radio wifi off", off_func="nmcli radio wifi on", window=window, Start=current_info[3], Active_text=f"🌐 - {current_info[2]}", Inactive_text="No - 🌐")
        #q.Render_Button(190, 50, 120, 50, on_func="bluetoothctl power on && nmcli radio wifi on", off_func="bluetoothctl power off nmcli radio wifi off", window=window, Start=current_info[4], Active_text=f"✈️", Inactive_text="✈️ - off")
        current_time=float(f'{q.datetime.datetime.now()}'.split()[1].split(':')[2])
        if target > 60:
            target = target-60
        if current_time>=target:
            Mesh_func()
            target=current_time+0.5
        pygame.event.clear()
        if q.UI.Update_UI==True:
            q.pygame.display.flip()
            q.UI.Update_UI=False

        time.sleep(1/15)
if __name__=="__main__":
    #try:
    main()
    #except (Exception, KeyboardInterrupt) as e:
    #    print(f"\nkilled, Reason({e})")