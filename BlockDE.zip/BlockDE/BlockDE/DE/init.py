try:
    import BlockUtils as q
    
except ImportError:
    print("\n\n\n")
    print("One or more runtime dependencies failed to load.\nPlease check your environment for any missing or corrupted files. Otherwise, you can run the trouble-shooter program to automatically resolve any issues.")
    exit()
runtime_stat = ['R']
try:
    cmd="ls && sudo --help && ls /home && ls /bin && ls /proc && ls /usr && ls /dev && ls /sbin && ls /lib"
    q.subprocess.run(cmd.split())
    q.subprocess.run(['clear'])
    q.run_bash("python3 Quick_Settings_Menu.py")
    q.run_bash("python3 Launcher.py")
    q.run_bash("python3 Background.py")
    q.time.sleep(0.2)
except Exception:
    print("This system is unsuitable for running BlockDE smoothly.")

displays=q.get_monitor_details()
print(displays)
primary_monitor=q.find_primary_display(displays)

current_info = ['00', '0', 'no']

q.os.environ['SDL_VIDEO_WINDOW_POS'] = f"{displays[primary_monitor][0]},{displays[primary_monitor][1]+displays[primary_monitor][3]-30}"  # X=100, Y=200
window = q.pygame.display.set_mode((displays[primary_monitor][2], 30), (q.pygame.NOFRAME))

running=True


pid=[q.os.getpid()]

def Mesh_func():
    try:
        v1=(q.Get_time())
        v2=(q.battery_info())
        v3=(q.wifi_details(1))
        v4=q.subprocess.run(('bluetoothctl show | grep -q "Powered: yes" && echo True || echo False').split(), capture_output=True, text=True).stdout.strip().split()
        current_info.clear()
        current_info.append(v1)
        current_info.append(v2)
        current_info.append(v3)
        current_info.append(v4)
        q.UI.Update_UI=True
    except Exception as e:
        print(f"Something went wrong...({e}) Relaunching operations in 2 seconds.")
        pass



try:
    conf = q.open_file("Taskbar/.config/preferences.conf").strip('').split("\n")
except FileNotFoundError:
    conf = 'Light '

def main():
    info_worker = q.threading.Thread(None, Mesh_func, daemon=True)
    info_worker.start()
    q.time.sleep(0.2)  # wait for window creation

    pid = q.os.getpid()

    # Get window id from PID
    win_id = q.subprocess.check_output(["xdotool", "search", "--pid", str(pid)])
    win_id = win_id.decode().split()[0]

    # Force always-on-top
    q.subprocess.call(["wmctrl", "-i", "-r", win_id, "-b", "add,skip_taskbar"])
    q.subprocess.call(["wmctrl", "-i", "-r", win_id, "-b", "add,above"])
    q.subprocess.call(["wmctrl", "-i", "-r", win_id, "-b", "add,dock"])
    FPS = 15
    target = float(f'{q.datetime.datetime.now()}'.split()[1].split(':')[2])+2
    q.UI.Update_UI=True
    while running:
        for event in q.pygame.event.get():
            if event.type == q.pygame.QUIT:
                q.sys.exit()

        if event.type == q.pygame.WINDOWFOCUSLOST:
            FPS=15
        elif event.type == q.pygame.WINDOWFOCUSGAINED:
            FPS=60
        window.fill((20,20,20))
        mx, my = q.pygame.mouse.get_pos()
        if mx > 0 and mx <= displays[primary_monitor][2] and my > 0:
            q.run_bash(f"wmctrl -i -a {win_id}")
        q.Render_UI(displays[primary_monitor][2]-210, 0, 185, 30, (20,20,20), f"🕒{current_info[0]} | 🔋{round(float(current_info[1]))}% | 🌐{current_info[2]}", 8, (0,255,255), q.Raise_APP,"Start_Menu", window=window)
        q.Render_UI(0,0,30,30,(255,165,0), "▦",16,click_func=q.Raise_APP,flags="Launcher", window=window)
        if q.UI.Update_UI==True:
            q.pygame.display.flip()
            q.UI.Update_UI=False
        q.pygame.event.clear()

        if runtime_stat[0]=='S':
            q.sys.exit()
        current_time=float(f'{q.datetime.datetime.now()}'.split()[1].split(':')[2])
        if target > 60:
            target = target-60
        if current_time>=target:
            Mesh_func()
            target=current_time+1
            q.IPC_MSG("", f"{current_info[2]}", overwrite=True, path="/dev/shm/BlockDE/Data.txt")
        q.time.sleep(1/FPS)

        
if __name__=="__main__":
    try:
        main()
    except (Exception, KeyboardInterrupt) as e:
        print(f"\nkilled, Reason({e})")
