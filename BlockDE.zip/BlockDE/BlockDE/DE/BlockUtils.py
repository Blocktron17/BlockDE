if __name__=="__main__":
    print("Wroong File. Please select an executable document that dosen't contain 'lib' within it's name!!!")
    exit()

import importlib

mod = []
#Construct a list of modules for Python3 to import.
modules_to_load = [
    'subprocess', 'pygame', 'time', 'os', 'threading', 'screeninfo', 'sys', 'datetime'
]
#Loop throughout the "modules_to_load" list and load each module by it's corosponding reference.
for m in modules_to_load:
    mod.append(importlib.import_module(m))

#Reconstruct the reference points for each module object in "mod".
subprocess=mod[0]
pygame=mod[1]
time=mod[2]
os=mod[3]
threading=mod[4]
screeninfo=mod[5]
sys=mod[6]
datetime=mod[7]
pygame.font.init()
font=pygame.font.Font("fonts/seguiemj.ttf", 16)
Application_Dir="/usr/share/applications"
#Define all functions that shall reside in "BlockUtils".
class UI:
    text_buffer = ""  # persistent storage for input text
    Update_UI=True
    @staticmethod
    def input_field(x, y, w, h, prompt="Input Text", bRGB=(70,70,70), tRGB=(0,165,165), window=None):
        # Draw the box with current text (prompt + buffer)
        display_text = prompt + ": " + UI.text_buffer
        Render_UI(x, y, w, h, bRGB, display_text, 16, tRGB, window=window)
        return UI.text_buffer
    @staticmethod
    def handle_event(event):
        if event.type == pygame.KEYDOWN:
            UI.Update_UI=True
            if event.key == pygame.K_BACKSPACE:
                UI.text_buffer = UI.text_buffer[:-1]
            elif event.key == pygame.K_ESCAPE:
                pass

            elif event.key == pygame.K_RETURN:
                UI.text_buffer = UI.text_buffer+""  # clear after enter
            else:
                UI.text_buffer += event.unicode  # add typed character

def Minimize_APP(win_id, ID):
    IPC_MSG(ID, "hidden")
    subprocess.call(["wmctrl", "-i", "-r", win_id, "-b", "add,skip_taskbar"])
    subprocess.call(["wmctrl", "-i", "-r", win_id, "-b", "add,hidden"])
    pygame.display.flip()
    while True:
        file = open_file("/dev/shm/BlockDE/Block_Cache.txt")
        if file.__contains__(f"{ID}\nshow"):
            IPC_MSG("", "", overwrite=True)
            subprocess.call(["wmctrl", "-i", "-r", win_id, "-b", "remove,hidden"])
            pygame.display.flip()
            break
        time.sleep(0.2)

def Raise_APP(ID):
    IPC_MSG(ID, "show")

def pid_to_window_id(pid):
    out = subprocess.check_output(["wmctrl", "-lp"]).decode().splitlines()
    for line in out:
        parts = line.split()
        if len(parts) >= 3 and parts[2] == str(pid):
            return parts[0]
    return None

def wifi_details(num1=1):
    try:
        # Get the currently active Wi-Fi details
        cmd = "nmcli -t -f ACTIVE,SSID,SIGNAL,BARS,SECURITY dev wifi"
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        line = next((l for l in result.stdout.splitlines() if l.startswith("yes:")), None)
        
        if not line:
            return 0
        
        # Remove the "yes:" and split the rest
        fields = line.split(":")[1:]
        
        # Replace with double spaces for your formatting request
        fields = [f.strip() for f in fields]
        return int(fields[num1] if num1 < len(fields) else 0)
    
    except Exception:
        return 0

def battery_info(string='percentage:'):
    cmd = "upower -i /org/freedesktop/UPower/devices/battery_BAT0".split()
    battery = subprocess.run(cmd, capture_output=True, text=True).stdout.strip().split()
    try:
        result=[]
        for m in range(len(battery)):
            tmp = battery[m]
            result.append(tmp.strip())
        for i in range(len(result)):
            if result[i].__contains__(string):
                try:
                    return result[i+1].strip('%')
                except IndexError:
                    return "N/A"
    except Exception:
        return("N/A")

def run_bash(args, kill=False):
    """
    Executes a bash script within the subprocess.popen() function wrapper.
    """
    try:
        #args = args+"& disown & exit"
        subprocess.Popen(args.split())
        if kill:
            print("exiting")
            pygame.quit()
            sys.exit()
    except BaseException as e:
        print(e)
        return e

def Get_Brightness():
    """
    This function gets the brightness of the defualt laptop display in percent, relative to the max supported brightness of the laptop display.
    """
    cmd = 'echo "$(brightnessctl g)a$(brightnessctl m)"'
    result = (subprocess.run(cmd, shell=True, capture_output=True, text=True).stdout.strip())
    result=result.split('a')
    return int(result[0]), int(result[1])

def Get_list_of_apps(apps_dir=None):
    """
    Acquires a list of all "*.desktop" files which reside in a directory.(This function explicitly pertains to Linux systems.)
    """
    cmd = f'ls {apps_dir}'
    result = (subprocess.run(cmd, shell=True, capture_output=True, text=True).stdout.strip())
    result=result.split()
    return result

def Get_time():
    """
    Gets the time of the system, using your local system time.
    """
    vtime=f"{(datetime.datetime.now())}".split()
    dtime=vtime[0]
    htime=f"{vtime[1]}".split(":")
    result = []
    for i in range(len(htime)):
        result.append(round(float(htime[i])))
    return(f"{result}")

def Set_Brightness(value):
    """
    This function sets the brightness of the defualt laptop display in percent, relative tothe max supported brightness of the laptop display.
    """
    run_bash(f"brightnessctl set {value}%")

def Get_Volume():
    """
    Gets the volume of the system as a '%', through the use of the "pactl" linux utility.
    """
    cmd = """pactl get-sink-volume @DEFAULT_SINK@ | grep -oP '\d+%' | head -1 | tr -d '%'"""
    result = (subprocess.run(cmd, shell=True, capture_output=True, text=True).stdout.strip())
    return int(result)

def Set_Volume(value):
    """
    This function is dedicated towards setting the volume percent of the system, through the use of the "pactl" linux utility.
    """
    run_bash(f"pactl set-sink-volume @DEFAULT_SINK@ {value}%")

def get_monitor_details():
    """
    Get monitor details as raw numeric lists.
    Format per monitor: [x, y, width, height, is_primary]
    """
    monitors = []
    try:
        from screeninfo import get_monitors
        for m in get_monitors():
            monitors.append([
                int(m.x),
                int(m.y),
                int(m.width),
                int(m.height),
                1 if getattr(m, "is_primary", False) else 0
            ])
    except Exception:
        # Fallback using tkinter (primary monitor only)
        try:
            import tkinter as tk
            root = tk.Tk()
            monitors.append([
                0,
                0,
                int(root.winfo_screenwidth()),
                int(root.winfo_screenheight()),
                1
            ])
            root.destroy()
        except Exception:
            return [[0, 0, 1280, 720, 1]]
    return monitors

def find_primary_display(monitors=list):
    """
    Returns an integer value that represents the display which houses the "is_primary" as true.
    """
    for m in range(len(monitors)):
        if monitors[m][4]==1:
            return m
    return 0

def open_file(path):
    """
    Instructs the OS to import a file into python's memory space.
    """
    with open(path, 'r') as file:
        return file.read()
    

def IPC_MSG(name="Val1", contents="", path="/dev/shm/BlockDE/Block_Cache.txt", overwrite=False):
    # Ensure directory exists
    os.makedirs(os.path.dirname(path), exist_ok=True)

    # Choose mode: overwrite ("w") or append ("a")
    mode = "w" if overwrite else "a"

    try:
        with open(path, mode) as file:
            file.write(f"\n{name}\n{contents}\n")
    except FileNotFoundError:
        # If file somehow doesn't exist, fall back to create
        with open(path, "x") as file:
            file.write(f"{name}\n{contents}\n")

def Render_UI(x, y, w, h, RGB, text=None, size=16, tRGB=(255,255,255), click_func=None, flags=None, flags1=None, window=None):
    """
    Draws a rectangular button and returns click data when the left mouse button
    is pressed down on the button (edge-detected). Returns:
      - click_func() result if click_func provided and button clicked,
      - True if button clicked but no click_func provided,
      - None otherwise.

    Edge detection implemented by a per-function attribute _last_pressed to avoid
    multiple returns while the mouse button is held.
    """
    rect = pygame.Rect(x, y, w, h)
    # Create rect and draw it
    pygame.draw.rect(window, (RGB[0], RGB[1], RGB[2]), rect)

    # Centered text rendering (approximate centering)
    if text is not None:
        text_surf = font.render(text, True, tRGB)
        tx = x + (w - text_surf.get_width()) / 2
        ty = y + (h - text_surf.get_height()) / 2
        window.blit(text_surf, (tx, ty))
    else:
        pass
    # Initialize edge-state the first time this function runs
    if not hasattr(pygame, "_ui_render_state"):
        pygame._ui_render_state = {}
    state = pygame._ui_render_state.setdefault('Render_UI', {"_last_pressed": False})

    # Mouse state (do NOT call pygame.event.get() here so main loop keeps events)
    mx, my = pygame.mouse.get_pos()
    left_pressed = pygame.mouse.get_pressed()[0]  # left button

    clicked_result = None
    # Edge detection: pressed now, not pressed last frame, and mouse over rect
    if rect.collidepoint(mx, my) and left_pressed and not state["_last_pressed"]:
        state["_last_pressed"] = True
        if click_func is not None:
            # call user-provided function and return its result
            try:
                if flags1:
                    clicked_result = click_func(flags, flags1)
                    clicked_result = True
                else:
                    clicked_result = click_func(flags)
                    clicked_result = True

            except Exception as e:
                # avoid crashing the UI; return the exception for debugging
                clicked_result = e
        else:
            clicked_result = True
        return clicked_result

    # If the button is released, clear the last-pressed flag so next click registers
    if not left_pressed:
        state["_last_pressed"] = False

    # Nothing to return when not clicked
    return None

def Percent_Bar(d1, d2, bx, by, bw, bh=2, mode='horizontal', brgb=(200,200,200), frgb=(0,165,165), changeable=False, with_func=None, window=None):
    x, y= bx, by
    w=0
    h=0
    if mode=="horizontal":
        w=d1*bw/d2
        h=bh
        w1=bw
        h1=bh
    elif mode=="vertical":
        w=bh
        h=d1*bw/d2
        w1=bh
        h1=bw
        by=by-h1-h
    else:
        return "Error"

    Render_UI(bx, by, w1, h1, brgb, None, 16, window=window)
    Render_UI(bx, by, w, h, frgb, None, 16, window=window)
    rect = pygame.Rect(bx, by, w1, h1)
    if changeable:

        # Mouse state (do NOT call pygame.event.get() here so main loop keeps events)
        mx, my = pygame.mouse.get_pos()
        left_pressed = pygame.mouse.get_pressed()[0]  # left button

        clicked_result = None
        # Edge detection: pressed now, not pressed last frame, and mouse over rect
        if rect.collidepoint(mx, my) and left_pressed:
            if with_func is not None:
                # call user-provided function and return its result
                try:
                    if mode == "horizontal":
                        percent = (mx - bx) / w1
                    elif mode == "vertical":
                        percent = (my - by) / h1
                    else:
                        percent = 0

                    # clamp between 0 and 1
                    percent = max(0, min(1, percent))

                    if with_func is not None:
                        clicked_result = with_func(f'{percent*100+1}')
                    else:
                        clicked_result = True
                except Exception as e:
                    clicked_result = e
                UI.Update_UI=True
                return clicked_result

def Render_Button(x, y, w, h, aRGB=(0,165,165), iRGB=(60,60,60), on_func=None, off_func=None, Active_text="on", Inactive_text="off", tRGB=(255,255,255), window=None, Start=True):
    """
    Draws a rectangular button and returns click data when the left mouse button
    is pressed down on the button (edge-detected). Returns:
      - click_func() result if click_func provided and button clicked,
      - True if button clicked but no click_func provided,
      - None otherwise.

    Edge detection implemented by a per-function attribute _last_pressed to avoid
    multiple returns while the mouse button is held.
    """

    # Initialize edge-state the first time this function runs
    if not hasattr(pygame, "_ui_render_state"):
        pygame._ui_render_state = {}
    _last_pressed = pygame._ui_render_state.setdefault('_last_pressed', {"_last_pressed": False})
    _Active  = pygame._ui_render_state.setdefault('_Active', {"_Active": Start})
    rect = pygame.Rect(x, y, w, h)
    # Create rect and draw it
    if _Active["_Active"]==True:
        pygame.draw.rect(window, (aRGB[0], aRGB[1], aRGB[2]), rect)

        # Centered text rendering (approximate centering)
        if Active_text is not None:
            text_surf = font.render(Active_text, True, tRGB)
            tx = x + (w - text_surf.get_width()) / 2
            ty = y + (h - text_surf.get_height()) / 2
            window.blit(text_surf, (tx, ty))
        else:
            pass
    elif _Active["_Active"]==False:
        pygame.draw.rect(window, (iRGB[0], iRGB[1], iRGB[2]), rect)

        # Centered text rendering (approximate centering)
        if Active_text is not None:
            text_surf = font.render(Inactive_text, True, tRGB)
            tx = x + (w - text_surf.get_width()) / 2
            ty = y + (h - text_surf.get_height()) / 2
            window.blit(text_surf, (tx, ty))
        else:
            pass
    # Mouse state (do NOT call pygame.event.get() here so main loop keeps events)
    mx, my = pygame.mouse.get_pos()
    left_pressed = pygame.mouse.get_pressed()[0]  # left button

    clicked_result = None
    # Edge detection: pressed now, not pressed last frame, and mouse over rect
    if rect.collidepoint(mx, my) and left_pressed and not _last_pressed["_last_pressed"]:
        _last_pressed["_last_pressed"] = True
        if on_func or off_func is not None:
            UI.Update_UI=True
            # call user-provided function and return its result
            try:
                if _Active["_Active"]==True:
                    clicked_result = run_bash(on_func, False)
                    _Active["_Active"]=False
                else:
                    clicked_result = run_bash(off_func, False)
                    _Active["_Active"]=True
                pygame.event.clear()
            except Exception as e:
                # avoid crashing the UI; return the exception for debugging
                clicked_result = e
        else:
            clicked_result = True
        return clicked_result

    # If the button is released, clear the last-pressed flag so next click registers
    if not left_pressed:
        _last_pressed["_last_pressed"] = False
        UI.Update_UI=True
    # Nothing to return when not clicked
    return None

def Render_Item_list(x, y, w, h, item_list=list, tRGB=(0,165,165), bRGB=(20,20,20), outline=True, start_at=0, key=list, sfilter="", scroll="", window=None):
    list_len=len(item_list)
    if sfilter=="":
        sfilter=""
    else:
        start_at=0
    a=0

    if start_at<=-1:
        start_at=0
    elif start_at>=list_len-1:
        start_at=list_len-1
    ran=0
    rect = pygame.Rect(x, y, w, h)
    item_list = list(filter(lambda x: sfilter in x, item_list))
    try:
        ny=y
        for i in range(len(item_list)):
            if ny<h:
                try:
                    n=i+start_at
                    if i==0:
                        abRGB=(0,120,120)
                        atRGB=(255,255,255)
                        out = Render_UI(x,ny,w,20,abRGB,item_list[n], 16, atRGB, run_bash, f"cd / && pcmanfm-qt {Application_Dir}/{item_list[n]}", False, window=window)
                    else:
                        out = Render_UI(x,ny,w,20,bRGB,item_list[n], 16, tRGB, run_bash, f"cd / && pcmanfm-qt {Application_Dir}/{item_list[n]}", False, window=window)
                    if not out == None:
                        return 0, 1
                    ny=ny+20
                except Exception:
                    a=a+1
                a=a+1
            else:
                break
        if item_list==[] and sfilter=="":
            Render_UI(x,y,w,30,(20,20,20),"No items could be displayed!!\nPlease double-check the shortcuts path.", window=window)
        elif item_list==[] and not sfilter=="":
            Render_UI(x,y,w,30,(20,20,20),f'No items match your search. "{sfilter}"', window=window)
    except Exception as e:
        Render_UI(x,y,w,h,(0,0,0), window=window)
        Render_UI(x,y,w,30,(255,0,0),"An Error has occurred!!", window=window)
        print(e)
        return 0, 0

    mx, my = pygame.mouse.get_pos()
    if rect.collidepoint(mx, my):
        if key[pygame.K_DOWN] or scroll=="DOWN":
            UI.Update_UI=True
            return start_at+1, 0
        elif key[pygame.K_UP] or scroll=="UP":
            UI.Update_UI=True
            return start_at-1, 0
        elif key[pygame.K_RETURN]:
            try:
                run_bash(f"pcmanfm-qt {Application_Dir}/{item_list[start_at]}", False)
                return start_at, 1
            except Exception as e:
                UI.Update_UI=True
                print(e)
                pass
    return start_at, 0
