import pygame
import time
import os
import subprocess

running=True
runtime_stat=['R']

def get_monitor_details():
    """
    Get monitor details as raw numeric lists.
    Format per monitor: [x, y, width, height, is_primary]
    """
    monitors = []
    try:
        from screeninfo import get_monitors
        for m in get_monitors():
            monitors.append([
                int(m.x),
                int(m.y),
                int(m.width),
                int(m.height),
                1 if getattr(m, "is_primary", False) else 0
            ])
    except Exception:
        # Fallback using tkinter (primary monitor only)
        try:
            import tkinter as tk
            root = tk.Tk()
            monitors.append([
                0,
                0,
                int(root.winfo_screenwidth()),
                int(root.winfo_screenheight()),
                1
            ])
            root.destroy()
        except Exception:
            return [[0, 0, 1280, 720, 1]]
    return monitors

def find_primary_display(monitors=list):
    for m in range(len(monitors)):
        if monitors[m][4]==1:
            return m
    return 0
displays=get_monitor_details()
primary_monitor=find_primary_display(displays)

#The following initializes the Pygame display environment
os.environ['SDL_VIDEO_WINDOW_POS'] = f"0,0"  # X=100, Y=200
window = pygame.display.set_mode((2560, 1440), (pygame.NOFRAME))

def run_bash(args):
    try:
        #args = args+"& disown & exit"
        argsv = args.split()
        subprocess.Popen(argsv)
    except BaseException as e:
        print(e)
        return e

pid=[os.getpid()]


#threading.Thread(None, Mesh_func, daemon=True).start()
def main():

    try:
        pid = os.getpid()
        time.sleep(0.2)
        try:
            # Get window id from PID
            win_id = subprocess.check_output(["xdotool", "search", "--pid", str(pid)])
            win_id = win_id.decode().split()[0]
        except Exception:
            # Get window id from PID
            win_id = subprocess.check_output(["xdotool", "search", "--pid", str(pid)])
            win_id = win_id.decode().split()[0]
        # Force always-on-bottom
        subprocess.call(["wmctrl", "-i", "-r", win_id, "-b", "add,skip_taskbar"])
        subprocess.call(["wmctrl", "-i", "-r", win_id, "-b", "add,below"])
        FPS = 0.1
        while running:
            time.sleep(1/FPS)
            if runtime_stat[0]=='S':
                exit()
    except Exception:
        pass
if __name__=="__main__":
    main()
