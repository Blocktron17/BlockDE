#!/bin/python3.13
import time
import os
import subprocess
import BlockUtils as q
Application_Dir="/usr/share/applications"
App_list=['Loading...']
current_info=[[]]
current_win_prop = [380, 300]


displays=q.get_monitor_details()
primary_monitor=q.find_primary_display(displays)

os.environ['SDL_VIDEO_WINDOW_POS'] = f"{displays[primary_monitor][0]},{displays[primary_monitor][1]+displays[primary_monitor][3]-30-current_win_prop[1]-5}"  # X=100, Y=200
window = q.pygame.display.set_mode((current_win_prop[0], current_win_prop[1]), (q.pygame.NOFRAME))

running=True

@staticmethod
def Mesh_func():
    a=q.Get_list_of_apps(Application_Dir)
    current_info.clear()
    current_info.append(a)

conf = 'Dark '.split()

@staticmethod
def main():
    return1=0, 0
    pid = os.getpid()
    q.time.sleep(0.2)
    # Get window id from PID
    win_id = subprocess.check_output(["xdotool", "search", "--pid", str(pid)])
    win_id = win_id.decode().split()[0]
    q.Minimize_APP(win_id, 'Launcher')
    # Force always-on-top
    q.subprocess.call(["wmctrl", "-i", "-r", win_id, "-b", "add,skip_taskbar"])
    q.subprocess.call(["wmctrl", "-i", "-r", win_id, "-b", "add,above"])
    q.subprocess.call(["wmctrl", "-i", "-r", win_id, "-b", "add,dock"])
    running = True
    Mesh_func()
    target = float(f'{q.datetime.datetime.now()}'.split()[1].split(':')[2])+2
    q.UI.Update_UI=True
    while running:
        for event in q.pygame.event.get():
            q.UI.handle_event(event)
            if event.type == q.pygame.QUIT:
                running = False
        if event.type == q.pygame.MOUSEWHEEL:
            if event.y > 0:
                mc = "UP"
                q.UI.Update_UI=True
            elif event.y < 0:
                mc = "DOWN"
                q.UI.Update_UI=True
            elif event.y == 0:
                mc = ""
        else:
            mc=""
        mx, my = q.pygame.mouse.get_pos()
        if mx > 0 and mx <= displays[primary_monitor][2] and my > 0:
            q.run_bash(f"wmctrl -i -a {win_id}")
        keys = q.pygame.key.get_pressed()
        if keys[q.pygame.K_ESCAPE] or return1[1]==1:
            q.Minimize_APP(win_id, 'Launcher')
        if conf[0]=="Dark":
            window.fill((20,20,20))
        else:
            window.fill((255,255,255))
        out=q.UI.input_field(0, 265, current_win_prop[0], 30, prompt="Input Text", bRGB=(70,70,70), tRGB=(0,165,165), window=window)
        return1 = q.Render_Item_list(0, 0, current_win_prop[0], 260, current_info[0], start_at=return1[0], key=keys, sfilter=out, scroll=mc, window=window)
        if q.UI.Update_UI==True:
            q.pygame.display.flip()
            q.UI.Update_UI=False
        time.sleep(1/15) 

if __name__=="__main__":
    try:
        main()
    except (Exception, KeyboardInterrupt) as e:
        print(f"\nkilled, Reason({e})")