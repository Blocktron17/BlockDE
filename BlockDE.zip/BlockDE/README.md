# BlockDE

## Introduction

BlockDE is a specialized, standalone Desktop environment specifically crafted to run atop the openbox session with minimal system dependencies and reduced runtime overhead, compared to mainstream DEs such as GNOME, KDE-Plasma, Deepin, etc. [source]("https://itsfoss.com/best-linux-desktop-environments/") BlockDE is designed with the intent to provide a userfriendly experience for those who reside on opposing ends of the technical spectrum, while providing a clean slate for real-time applications(e.g gaming, scientific experiemmentation and embedded computing) and user curated customizations without system-level overhead.

## Why select BlockDE?

By selecting BlockDE as your default desktop environment, is analogous towards acquiring unfearthered dominion over your digital steed. BlockDE has been constructed with the 'User-First' design philosophy in-mind, where we, the developers design your desktop for usability, modularaity and multiplatform use.

## Installation Procedures

Follow the instructions below to setup your new desktop environment:

    1. Open the your prefered terminal and type the following:
```bash
sudo 
```